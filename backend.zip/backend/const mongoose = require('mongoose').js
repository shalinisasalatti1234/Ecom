const mongoose = require('mongoose')

async function connectDB() {
    try{
        await mongoose.connect(ProcessingInstruction.env.MONGO_URI)
        console.log('MongoDB Connected');
    }
    catch(error){
        console.error(`Error connecting to mongoDB: ${error.message}`)
        Process.exit(1)
    }

}

module.exports = connectDB;
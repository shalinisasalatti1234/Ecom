const express = require('express');
const router = express.Router();

const {
  addToCart,
  getCart,
  updateCartItem,
  clearCart,
} = require('../controllers/cartController');

const { authMiddleware } = require('../middleware/authMiddleware');

router.use(authMiddleware); // All cart routes require auth

router.post('/add', addToCart);
router.get('/', getCart);
router.put('/update', updateCartItem);


module.exports = router;

const Product = require('../models/Product');

exports.addProduct = async (req, res) => {
  try {
    const { name, brand, description, price, stockQuantity } = req.body;

    const existingProduct = await Product.findOne({ name });
    if (existingProduct) return res.status(400).json({ msg: 'Product already exists' });

    const newProduct = new Product({
      name,
      brand,
      description,
      price,
      stockQuantity,
      uploadedBy: req.user.id,
    });

    await newProduct.save();

    res.status(201).json({ msg: 'Product added', data: newProduct });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server Error' });
  }
};

exports.getProducts = async (req, res) => {
  try {
    const products = await Product.find().sort({ createdAt: -1 });
    res.json({ products });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server Error' });
  }
};

exports.getProductById = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ msg: 'Product not found' });
    res.json({ product });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server Error' });
  }
};

exports.updateProduct = async (req, res) => {
  try {
    const { name, brand, description, price, stockQuantity } = req.body;
    const updatedFields = {};
    if (name) updatedFields.name = name;
    if (brand) updatedFields.brand = brand;
    if (description) updatedFields.description = description;
    if (price !== undefined) updatedFields.price = price;
    if (stockQuantity !== undefined) updatedFields.stockQuantity = stockQuantity;

    const updatedProduct = await Product.findByIdAndUpdate(
      req.params.id,
      { $set: updatedFields },
      { new: true }
    );
    if (!updatedProduct) return res.status(404).json({ msg: 'Product not found' });

    res.json({ msg: 'Product updated', updatedProduct });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server Error' });
  }
};

exports.deleteProduct = async (req, res) => {
  try {
    const deletedProduct = await Product.findByIdAndDelete(req.params.id);
    if (!deletedProduct) return res.status(404).json({ msg: 'Product not found' });
    res.json({ msg: 'Product deleted' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server Error' });
  }
};

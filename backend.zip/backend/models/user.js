const mongoose = require('mongoose');

// Cart subdocument schema
const cartSchema = new mongoose.Schema({
  product: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'product',  // Make sure this matches your Product model name
    required: true,
  },
  quantity: {
    type: Number,
    default: 1,
    required: true,
  },
});

// User schema
const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  password: {
    type: String,
    required: true,
  },
  role: {
    type: String,
    enum: ['admin', 'user'],
    default: 'user',
  },
  cart: [cartSchema], // Reference cartSchema here, after declaring it
}, { timestamps: true });

module.exports = mongoose.model('User', userSchema);

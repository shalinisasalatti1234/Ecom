const adminMiddleware = (req,res,next)=>{
    if(req.User.role !== 'admin'){
        return res.status(403).json({
            msg:`Forbidden`
        })
    }
    next()
}

module.exports = adminMiddleware
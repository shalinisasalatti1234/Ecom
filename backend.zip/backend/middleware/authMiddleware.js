// Simple example of auth middleware
exports.authMiddleware = (req, res, next) => {
  // Usually you get token from headers and verify it
  const token = req.headers.authorization;

  if (!token) {
    return res.status(401).json({ message: 'Unauthorized: No token provided' });
  }

  // Dummy check (replace with real JWT or session check)
  if (token === 'valid-token') {
    req.user = { id: 'mockUserId' }; // Mock user info from token
    return next();
  }

  return res.status(401).json({ message: 'Unauthorized: Invalid token' });
};
